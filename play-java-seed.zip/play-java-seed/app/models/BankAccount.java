import java.util.*;

import javax.persistence.*;
import java.util.List;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import java.util.Date;
import java.util.Calendar;

@Entity
@Table (name = "Bank_Account")
public class BankAccount extends  Model {


    @Id
    private long id;

    @ManytoOne
    private Profile owner;

    @OnetoMany
    private List<Transactions> trans = new ArrayList<Transactions>();

    private String accNum;
    protected double balance;


    public BankAccount() {
        this.balance = 0;
    }


    public void deposit(double amount) {
        balance = balance + amount;
        addTrans(Calendar.getInstances(),amount,"Withdraw" ); 
    }

    public void withdraw(double amount) {
        balance = balance - amount;
        addTrans(Calendar.getInstances(),amount,"Withdraw" );   
    }

    public void Transfer(double amount, String a1){
        balance = balance - amount;
        addTrans(Calendar.getInstances(),amount,"Transfer to "+a1); 
    }

    public void addTrans(Date a1,double amount, String desc){
     Transactions a = new Transactions(a1, amount, desc);
    trans.add(a);   
     }

    public String getaccNum(){
        return accNum;
    }

    public double getBalance() {
        return balance;
    }

   
}

