

# --- Sample dataset

# --- !Ups
Create Table Profile(
    id int,
    Fname varchar2(255),
    Lname varchar2(255),
    Address varchar2(255),
    County varchar2(255),
    email varchar2(255),
    password varchar2(255),
    username varchar2(255),
    city varchar2(255),

)





