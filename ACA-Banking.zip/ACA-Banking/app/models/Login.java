package models;

public class Login {

    private String UserName;
    private String password;

    public String validate(){

        if(Profile.authenticate(getUsername(), getPasssword()) == null){
            return "invaild username or password "
        }


    
    public String getUsername(){
      return UserName;
    }

    public String getPassword(){
        return password;
    }
}