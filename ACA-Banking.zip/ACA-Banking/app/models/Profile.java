package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Profile extends Model{
    
    @Id
    private Long id;  

    @Constrataints.Required
    private String Fname;
    
    @Constrataints.Required
    private String Lname;

    @Constrataints.Required
    private String Username;

    @Constrataints.Required
    private String Password;

    @Constrataints.Required
    private String email;
    
    @Constrataints.Required
    private String address;

    @Constrataints.Required
    private String city;

    @Constrataints.Required
    private String county;
  
   
    @OneToOne
    private BankAccount a1;

public Profile() {
}

    public Profile(Long id,String Fname, String Lname, String Username, String Password, String email, String address, String city, String county) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.Username = Username;
        this.Password = Password;
        this.email = email;
        this.address = address;
        this.city = city;
        this.county = county;
        this.a1 = new BankAccount();
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

public int getAccno(){
    return a1.getaccNum
}
public Double getBal(){
    return a1.getBal
}
   
} 

public static void Finder<String, Profile> find - new Finder<String, User>(Profile.class);

public static List<Profile> FindAll(){
    return User.find.all();
}

public static Profile authenticate(String Username,String password){
    return find.query().where().eq("Username", Username).eq("password",password).findUnique();
}

publcic static Profile getProfilebyid(String Username)
if(id == null)
return null;
else
return find.byId(id);