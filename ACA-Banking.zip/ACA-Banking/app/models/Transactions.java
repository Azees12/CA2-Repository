package models;

import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import java.util.Date;
import java.util.Calendar;

@Entity
@Table (name ="Transactions")
public class Transactions extends Model{

@ID
private long id;

@Temporal(TemporalType.DATE)
private Date date;

private double amount;
private String desc;

@ManytoOne
private BankAccount trans;


public Transactions (Date a1,double amount,String desc) {
this.date = a1;
this.amount = amount;
this.desc = desc;

}

public long getTransID(){
 return this.id;
}

public double getTransAm(){
return this.amount;
}

public Date getTransdate(){
  return this.date;
}

public String getTransDesc(){
    return this.desc;
}



}