package controllers;
import play.mvc.*;
import views.*;
import models.*;
import javax.persistence.*;
import play.data.FormFactory;
import java.util.List;
import javax.inject.Inject;
/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
     
     private FormFactory formFactory;

     @Inject
     public HomeController(FormFactory f){
         this.formFactory = f;
     }
     
     public Result index() {
        return ok(views.html.Index.render());
        
    }


    public void updatePassword(Long id,String password){
    p = Profile p;
   
        p = Profile.find.by(Id);
        if(p != null)
        p.setPassword(password);
        p.save();

    } catch(Exception ex){
        return badRequest("Error")
    }
}

    public Result Profile(){
        return (views.html.Profile.render(BankAccount,TransactionList, Profile.getProfileById(session().get(email)));
    }

    public Result ContactUs() {
        return ok(views.html.ContactUs.render());
        
    }

    public Result about() {
        return ok(views.html.About.render());
        
    }

    public Result addProfile(){
        Form<Profile> profileForm = formFactory.form(Profile.class) ;
        return(addProfile.render(profileForm));
    }

    public Result addProfileSubmit(){
        Form <Profile> newProfileForm = formFactory.form(Profile.class).bindFromRequest();

        if(newProfileForm.hasErrors()){
            return badRequest(addProfile.render(newProfileForm));
        }
        else{
            Profile newProfile = newProfileForm.get();

            newProfile.save();

            flash("Your account was created");

            return redirect(controllers.routes.HomeController.index());
                }
    }
}
