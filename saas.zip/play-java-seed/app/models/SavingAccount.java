package models;

import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class SavingAccount extends BankAccount {

    private double interestRate;
    private String type = "Savings";

    public SavingAccount() {
       this.interestRate = 0.012;
    }
  
    public double getInterest(){
        return interestRate;
    }



}