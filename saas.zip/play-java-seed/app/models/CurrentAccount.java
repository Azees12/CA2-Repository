package models;

import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class CurrentAccount extends BankAccount {
 
    private String type = "Current";

    public CurrentAccount() {
    }



}